# Cassandra-project
a project based on data processing and training
The task is to build a model that helps estimating when
an invoice will be paid. The estimation doesn't have to
be an exact date and time, a rough estimation in terms
of days is sufficient for this task.
You need to predict the Number of Days until Payment
using the Dataset provided to you.
